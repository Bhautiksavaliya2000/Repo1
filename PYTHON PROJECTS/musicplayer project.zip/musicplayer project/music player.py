import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import filedialog
from PIL import Image,ImageTk
from mutagen.mp3 import MP3
from pygame import mixer
import os
import time
mixer.init()


#=======================================DEFINING BUTTON FUNCTION===================================================

def auto_play(event=None,songname=None):
    global indexno
    global song_length
    indexno = songlist.index(songname)
    mixer.music.load(os.path.join('E:\SONGS',songname))         # To join path name and song name.
    song = MP3(os.path.join('E:\SONGS',songname))               # To get length of the song.
    song_length = song.info.length
    pgbar.configure(to=song_length)
    print(type(song_length))
    mixer.music.play()
    # root.after(0.5,updating)

# def updating():
#     played_time = mixer.music.get_pos()/1000
#     pgbar.set(played_time)
#     root.after(1,updating)

def perform_play():    
    mixer.music.unpause()
        
def perform_pause():
    mixer.music.pause()
    
def perform_previous():   
    global indexno             # to update global variable.
    indexno-=1
    songstring = songlist[indexno]
    mixer.music.load(os.path.join("E:\SONGS",songstring))
    mixer.music.play()

def perform_next():
    global indexno 
    indexno+=1
    songstring = songlist[indexno]
    mixer.music.load(os.path.join('E:\SONGS',songstring))
    mixer.music.play()

def searching():                     #to make a list of matched string from songlist.
    global matched_songlist
    user_string = search_cbox_var.get()
    for i in range(len(songlist)):
        if user_string in songlist[i]:
            matched_songlist.append(songlist[i])
        else:
            pass
    search_cbox['values'] = tuple(matched_songlist)
    matched_songlist = []               # to delete previous searches.

def set_volume(event=None):
    vol_value = 1 - (float(event)/100)          # Increase volume when going upwards.
    mixer.music.set_volume(vol_value)

def skip(event=None):
    mixer.music.set_pos(float(event))
    
# def choose_dir():
#     global selectedfolder
#     selectedfolder = filedialog.askdirectory()
#     print(selectedfolder)
    
    
#==================================================LAYOUT DESIGN=====================================================


indexno=None
songlist = os.listdir('E:\SONGS')#List of all song in the directory.
                                     #to store reference for next and previous operation.
matched_songlist = []                #to store all matched song name with search string.
song_length = None                   #to store length of the song selected.
root = tk.Tk()
root.title("Melodies")
root.geometry("500x500")
root.configure(bg='#9932CC')
root.minsize(500,500)
root.maxsize(600,600)

topframe = tk.Frame(root,bg='#9932CC')
topframe.pack(side=TOP,padx=60,pady=10) 
bottomframe = tk.Frame(root,bg='#9932CC')
bottomframe.pack(side=BOTTOM,padx=90,pady=10)

searchlabel = tk.Label(topframe,text="search:",font = 'comicsansMS 12 bold',fg='#FFE4C4',bg='#9932CC')
searchlabel.pack(side=LEFT,anchor=N,padx=5,pady=2)

#to display similar song serched if exist. 
search_cbox_var = tk.StringVar()        
search_cbox = ttk.Combobox(topframe,width=20,textvariable=search_cbox_var)
search_cbox.pack(side=LEFT,pady=3)
search_cbox.bind("<<ComboboxSelected>>", lambda event: auto_play(event,search_cbox_var.get()))   #passing songname as parameter.

#search button.
searchimg = Image.open('G:\PYTHON\GUI\musicplayer project\search logo.png')
search_img = ImageTk.PhotoImage(searchimg.resize((30,30)))
searchbutton = tk.Button(topframe,image=search_img,command=searching,bd=0,bg='#9932CC')
searchbutton.pack(side=LEFT,padx=10)

#making combobox to choose the song.
cboxframe = tk.Frame(root,bg='#9932CC')
cboxframe.pack()
cbox_lable = tk.Label(cboxframe,text='choose a song:',font='comicsansMS 12 bold',fg='#FFE4C4',bg='#9932CC')
cbox_lable.pack(side=LEFT)
cbox_var = tk.StringVar()
song_combobox = ttk.Combobox(cboxframe,textvariable=cbox_var,width=30,state='readonly')
song_combobox['values'] = tuple(songlist)
song_combobox.bind("<<ComboboxSelected>>", lambda event: auto_play(event,cbox_var.get()))  #passing songname as parameter.
song_combobox.pack(side=LEFT)

# creating browse button
# Browsebutton = ttk.Button(cboxframe,text='Browse',command=choose_dir)
# Browsebutton.pack(side=LEFT,padx=5)

# display photo.
picframe = tk.Frame(root,bg='#9932CC')
picframe.pack()
img = Image.open(r"G:\PYTHON\GUI\musicplayer project\Capture.PNG")
resized = img.resize((200,200))
showimg = ImageTk.PhotoImage(resized)
piclabel = tk.Label(picframe,image=showimg,bg='#9932CC')
piclabel.pack(side=LEFT,pady=20)

# display song progress.
progressframe = tk.Frame(root)
progressframe.pack(side=BOTTOM,anchor=SW,)
pgr_double = tk.DoubleVar
pgbar = ttk.Scale(progressframe,from_=0,variable=pgr_double,orient='horizontal',length=500,command=skip,value=0.0)
pgbar.pack()


# making button images.
prev_img = Image.open(r"G:\PYTHON\GUI\musicplayer project\previous.png")
prev_resized = prev_img.resize((40,40))
prev_showing = ImageTk.PhotoImage(prev_resized)
prevbutton = tk.Button(bottomframe,image=prev_showing,bd=0,compound=CENTER,bg='#9932CC',command=perform_previous)
prevbutton.pack(side=LEFT,anchor=SW,padx=2)

pause_img = Image.open(r"G:\PYTHON\GUI\musicplayer project\pausebutton.png")
pause_resized = pause_img.resize((40,40))
pause_showing = ImageTk.PhotoImage(pause_resized)
pausebutton = tk.Button(bottomframe,image=pause_showing,bd=0,bg='#9932CC',borderwidth=0,command=perform_pause).pack(side=LEFT,anchor=SW,padx=2)

play_img = Image.open(r"G:\PYTHON\GUI\musicplayer project\play.png")
play_resized = play_img.resize((40,40))
play_showing = ImageTk.PhotoImage(play_resized)
playbutton = tk.Button(bottomframe,image=play_showing,bd=0,bg='#9932CC',command=perform_play).pack(side=LEFT,anchor=SW,padx=2)

next_img = Image.open(r"G:\PYTHON\GUI\musicplayer project\next.png")
next_resized = next_img.resize((40,40))
next_showing = ImageTk.PhotoImage(next_resized)
nextbutton = tk.Button(bottomframe,image=next_showing,bd=0,bg='#9932CC',command=perform_next).pack(side=LEFT,anchor=SW,padx=2)

#volume button.
vol = tk.IntVar()
volume_scale = ttk.Scale(bottomframe,from_=0,to_=100,variable=vol,orient='vertical',command=set_volume)
# volume_scale.bind("<ButtonRelease-1>",set_volume)     
volume_scale.pack(anchor=SE,side=BOTTOM,padx=40)
volume_scale.set(0)


root.mainloop()
